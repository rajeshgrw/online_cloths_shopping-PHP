<?php

$con = mysqli_connect("localhost","root","","wholeecom_store");

?>
