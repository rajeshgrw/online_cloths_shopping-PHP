<footer class="page-footer">

	<div class="page-footer__subline">
		<div class="container clearfix">

			<div class="copyright">
				&copy; 2024 Fashion&trade;
			</div>

			<div class="developer">
				
			</div>

			<div class="designby">
				
			</div>
		</div>
	</div>
</footer>
